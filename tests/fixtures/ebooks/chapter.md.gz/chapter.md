# The Picture of Dorian Gray

## Chapter 1

The studio was filled with the rich odour of roses, and when the light summer wind stirred amidst the trees of the garden, there came through the open door the heavy scent of the lilac, or the more delicate perfume of the pink-flowering thorn.

## Chapter 2

As they entered they saw Dorian Gray. He was seated at the piano, with his back to them, turning over the pages of a volume of Schumann's "Forest Scenes."

## Chapter 3

At breakfast, Lord Henry Wotton listened with amused attention to the serious eloquence of his uncle, George Fermor, an old gentleman of considerable vanity and very limited ideas.

## Chapter 4

One afternoon, a month later, Dorian Gray was reclining in a luxurious armchair, in the little library of Lord Henry's house in Mayfair.

## Chapter 5

"My dear boy," said Lord Henry, smiling, "nobody has any respect for anybody else nowadays. It is the secret of society."

## Chapter 6

The room was filled with the scent of white lilies. Dorian Gray was standing by the window, looking out at the grey, continuous sky.

## Chapter 7

As he walked home, Dorian Gray felt a strange sense of relief. The world was still beautiful, and life was still sweet.

## Chapter 8

When he woke, it was already afternoon. The light was golden and warm, and the room was filled with the scent of flowers.

## Chapter 9

"It is better to be beautiful than to be good. But it is better to be good than to be ugly."

## Chapter 10

The painting seemed to have altered. The expression on the face was different. There was a touch of cruelty in the mouth.

## Chapter 11

For years, Dorian Gray could not free himself from the influence of that book. He procured from Paris no less than nine large-paper copies of the first edition.

## Chapter 12

It was on the ninth of November, the eve of his own thirty-eighth birthday, that he met Lord Henry in the conservatory of his house.

## Chapter 13

He walked slowly up the stairs, leaving the lamp burning behind him. The air was heavy with the scent of flowers.

## Chapter 14

The room was filled with the odor of the dead. Dorian Gray felt a sudden wave of nausea.

## Chapter 15

That evening, at eight o'clock, dressed in a wonderful suit of black velvet, he went to Lady Narborough's.

## Chapter 16

The cold, grey light of morning was filtering through the curtains when he returned home.

## Chapter 17

A week later, Dorian Gray was sitting in the conservatory at Selby Royal, talking to the Duchess of Monmouth.

## Chapter 18

The next day, he did not leave the house. He sat in the library, reading, or pretending to read.

## Chapter 19

"I have grown to love secrecy. It seems to be the one thing that makes modern life wonderful or mysterious to me."

## Chapter 20

When they entered the room, they saw upon the wall a splendid portrait of their master as they had last seen him, in all the wonder of his exquisite youth and beauty.