#!/usr/bin/env python3
"""Example Python module for viewport-editor code navigation tests.
LF line endings (Unix)."""

import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


# ── Constants ──────────────────────────────────────────────────────────

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8765
MAX_RETRIES = 3
TIMEOUT_SECONDS = 30


# ── Data Classes ───────────────────────────────────────────────────────

@dataclass
class ViewportConfig:
    """Configuration for a single viewport session."""
    display_mode: str = "prose"
    autosave: bool = False
    max_viewports: int = 10


@dataclass
class ClipboardEntry:
    """An item in the clipboard with provenance tracking."""
    content: str
    source_viewport: str
    source_line_start: int
    source_line_end: int
    timestamp: float = 0.0


# ── Core Functions ─────────────────────────────────────────────────────

def resolve_project_root() -> Path:
    """Resolve the project root from cwd or environment."""
    env_root = os.environ.get("VIEWPORT_PROJECT_ROOT")
    if env_root:
        return Path(env_root).resolve()
    return Path.cwd().resolve()


def create_viewport(config: ViewportConfig) -> dict:
    """Create a new viewport with the given configuration."""
    return {
        "display_mode": config.display_mode,
        "autosave": config.autosave,
        "max_viewports": config.max_viewports,
        "buffer": [],
        "dirty": False,
        "clipboard": [],
    }


def edit_buffer(viewport: dict, line: int, text: str) -> bool:
    """Replace the content at a given line in the viewport buffer."""
    if line < 0 or line >= len(viewport["buffer"]):
        return False
    viewport["buffer"][line] = text
    viewport["dirty"] = True
    return True


def find_symbol(buffer: list[str], symbol: str) -> Optional[int]:
    """Find a line containing the given symbol in the buffer."""
    for i, line in enumerate(buffer):
        if symbol in line:
            return i
    return None


# ── Main Entry Point ───────────────────────────────────────────────────

def main() -> int:
    """Run the viewport-editor server."""
    config = ViewportConfig()
    project_root = resolve_project_root()
    print(f"Starting viewport-editor in {project_root}")
    viewport = create_viewport(config)
    print(f"Viewport created: display_mode={viewport['display_mode']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())